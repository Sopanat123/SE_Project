package se.model;

import java.util.ArrayList;

/**
 *
 * @author Ben
 */
public class UserList {
    private ArrayList<User> list;
    
    public UserList() {
        list = new ArrayList<>();
    }
}
